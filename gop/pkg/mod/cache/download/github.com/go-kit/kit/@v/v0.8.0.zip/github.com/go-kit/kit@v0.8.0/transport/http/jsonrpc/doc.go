// Package jsonrpc provides a JSON RPC (v2.0) binding for endpoints.
// See http://www.jsonrpc.org/specification
package jsonrpc
