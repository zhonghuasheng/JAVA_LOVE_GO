// Package consul provides Instancer and Registrar implementations for Consul.
package consul
