# util

This directory holds packages of general utility to multiple consumers within Go kit,
 and potentially other consumers in the wider Go ecosystem.
There is no `package util` and will never be.
