import org.junit.Assert;
import org.junit.Test;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPoolConfig;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public class JedisClusterTest {

    @Test
    public void get() {
        Set<HostAndPort> nodes = new HashSet<HostAndPort>();
        nodes.add(new HostAndPort("172.18.163.40", 7000));
        nodes.add(new HostAndPort("172.18.163.40", 7001));
        nodes.add(new HostAndPort("172.18.163.40", 7002));
        nodes.add(new HostAndPort("172.18.163.40", 7003));
        nodes.add(new HostAndPort("172.18.163.40", 7004));
        nodes.add(new HostAndPort("172.18.163.40", 7005));
        JedisCluster jedisCluster = new JedisCluster(nodes, 30, 3);
        String value = jedisCluster.get("hello");
        System.out.println(value);
        Assert.assertEquals("word", value);
    }

    public void set() {

    }

    @Test
    public void singleMode() {
        Jedis jedis = new Jedis("172.18.163.40", 7002);
        System.out.println(jedis.get("test"));
    }
}
